package List2;

public class list_2_11 {
    public static void  main(String[] args) {
        int x;
        x = 1;
        System.out.println("До вложеного блока: x равно " + x);
        int y = 3;
        System.out.println("Внутренний ьлок: x равно " + x + "y равно " + y);
        x = y * 3;
    }
}

