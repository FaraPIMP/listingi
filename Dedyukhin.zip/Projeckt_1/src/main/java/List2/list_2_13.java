package List2;

class DivisionDemo {
    public static void main(String[] args) {
     int iresult, iremain; // для деления целых чисел
     double dresult, dremain; // для деления вещественных чисел
        // для деления целых чисел
        iresult = 10 / 3;
        iremain = 10 % 3;
        System.out.println("частное от деления 10 / 3 равно");
        System.out.println(iresult + ", остаток равно " + iremain);

        // деление вещественных чисел
        dresult = 10.0 / 3.0;
        dremain = 10.0 % 3.0;

        System.out.println("частное от деления 10.0 / 3.0 равно");
        System.out.println(dresult + ", остаток равне " + dremain);
    } // main(String[]) method
} // DivisionDemo
