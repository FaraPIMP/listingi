package List2;

 public class list_2_3 {
    public static void main(String[] args) {
        int a, b, c, d;

        a = 2;
        b = 3;
        System.out.println("a = 2, b = 3");
        if (a < b) System.out.println("a < b");
        if (a > b) System.out.println("Этот текст вы никогда не увидете");

        System.out.println("");
        c = a - b;
        System.out.println("c = -1");
        if (c > 0) System.out.println("c имеет положительное значение");
        if (c < 0) System.out.println("c имеет отрицательное значение");
        System.out.println("");

        d = b - a;
        System.out.println("d = 1");
        if (d >= 0) System.out.println("d имеет положительное значение");
        if (d < 0) System.out.println("d имеет отрицательное значение");
        System.out.println("");

        if (a + c != b) System.out.println("a плюс с не равняется b");
        if (a + c ==b) System.out.println("a плюс d равняется b");

    } // main() method


} // IfStatementDemo class
