package List2;

public class list_2_6 {
    public  static void main(String[] args) {
        char ch;
        ch = 'L';
        System.out.println("ch = " + ch);
        ch++;
        System.out.println("значение ch изменилось на " + ch);
        ch = 'Д';
        ch--;
        System.out.println("значение ch снова изменилось и равно " + ch);
    } // main(String[])

} // CharArithDemo class
