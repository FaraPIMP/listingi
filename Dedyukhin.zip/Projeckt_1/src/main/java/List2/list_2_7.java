package List2;

public class list_2_7 {
    public  static void main(String[] args) {
        double cathetus1, catgetus2, hypot;

        cathetus1 = 3;
        catgetus2 = 4;

        hypot = Math.sqrt((cathetus1 * cathetus1) + (catgetus2 * catgetus2));
        System.out.println("длина гипотенузы равна " + hypot);
    } // main(String[])
} // class HypotDemo
