package listing3;

class Vehicle6 {
    int passengers;
    int wheels;
    int maxspeed;
    int burnup;
    Vehicle6 (int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle(int,int,int,int) constructor
    double distance(double interval) {
        double val = this.maxspeed * interval;
        return val;
    } // distance(double) method
} // Vehicle class

class VehicleAccessDemo {
public static void main(String[] args) {
    Vehicle6 ferrari = new Vehicle6(2, 4, 360, 12);
    Double distance = ferrari.distance(0.5);
    System.out.println("Ferrari за полчаса проедет " + distance + " км. ");
    // следующая команда вызывает ошибку компиляции.
    // закомментируйте ее
    System.out.println("Скорость Ferrari: " + ferrari.maxspeed + " км/ч");

 } // main(String[]) method
} // VehicleAccessDemo class