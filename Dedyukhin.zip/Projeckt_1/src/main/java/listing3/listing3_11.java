package listing3;

class Vehicle7 {
    int passengers;
    private int wheels;
    private int maxspeed;
    int burnup;

    Vehicle7(int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle(int,int,int,int) constructor

    double distance(double interval) {
        double val = this.maxspeed * interval;
        return val;
    } // distance(double) method

    int getMaxspeed() {
        return this.maxspeed;
    }

    int getWheels() {
        return this.wheels;
    }

    void setWheels(int wheels) {
        if ((wheels < 1) || (wheels > 24)) {
            System.out.println("Неверное указано число колес.");
            return;
        }
        this.wheels = wheels;
    }
} // Vehicle class
    class VehicleGetSetMethod {
        public static void main(String[] args) {
            Vehicle7 ferrari = new Vehicle7(2, -2, 360, 12);
            System.out.println("Max скорость: " + ferrari.getMaxspeed() + " км/ч");
            System.out.println("Число колес: " + ferrari.getWheels());
            ferrari.setWheels(4);
            System.out.println("Число колес (повторно): " + ferrari.getWheels());
        } // main(String[]) method
    } // VehicleGetSetMethod class

