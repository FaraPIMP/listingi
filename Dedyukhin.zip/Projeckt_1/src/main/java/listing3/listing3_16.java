package listing3;

class Vehicle9 {
    int passengers;
    private int wheels;
    private int maxspeed;
    int burnup;
    Vehicle9() {
        // конструктор без параметров
        this(4, 4, 160, 13);
    } // Vehicle9() конструктор

    Vehicle9(int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle(int, int, int, int) конструктор

    double distance(int interval) {
        return distance((double) interval);
    } // distance(int)

    double distance(double interval) {
        double value = this.maxspeed * interval;
        return value;
    } // distance(double)
} // Vehicle class
