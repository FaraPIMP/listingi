package listing3;

class Vehicle4 {
    int passengers;
    int wheels;
    int maxspeed;
    int burnup;

    // конструкция с параметрами
    Vehicle4(int p, int w, int ms, int bu) {
        passengers = p;
        wheels = w;
        maxspeed = ms;
        burnup = bu;
    } // Vehicle4 (int, int, int, int)
   // расчет длины пройденного пути
    double distance(double interval) {
        double value = maxspeed * interval;
        return value;
    } // distance(double)

} // Vehicle class

class VehicleConstrDemo {

    public static void main(String[] args) {
        Vehicle4 car = new Vehicle4(2, 4, 130, 30);
        Vehicle4 bus = new Vehicle4(45, 4, 120, 25);

        double interval = 1;
        double distanceCar = car.distance(interval);
        double distanceBus = bus.distance(interval);

        System.out.println("Автомобиль с " + car.passengers + " пассажирами " + "проедет за 1 час " + distanceCar + " км. ");
        System.out.println("Автомобиль с " + bus.passengers + " пассажирами " + "проедет за 1 час " + distanceBus + " км. ");
    } // main(String[]) method
} // VehicleConstrDemo class
