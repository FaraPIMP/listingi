package listing3;

class Vehicle5 {
    int passengers;
    int wheels;
    int maxspeed;
    int burnup;

    Vehicle5 (int passengers, int wheels, int maxspeed, int burnup) {
        this.passengers = passengers;
        this.wheels = wheels;
        this.maxspeed = maxspeed;
        this.burnup = burnup;
    } // Vehicle конструктор
    double distance(double interval) {
        double value = this.maxspeed * interval;
        return value;
    } // distance(double) method
} // Vehicle class
