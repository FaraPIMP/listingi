package listing7;

public class listing7_2 {
}
